# eco-apps-pong

El parcial consiste en completar el programa del juego de PONG.

- Deben utilizar el arduino como control remoto.

- Con el actuador (potenciómetro o fotocelda), el usuario debe poder mover el personaje a lo ancho de la pantalla

- Deben utilizar un botón A que al presionarlo, debe reducir el ancho del jugador

- Deben utilizar un botón B que al presionarlo, debe aumentar la velocidad de movimiento de la bola.

- Cuando el jugador toque la pelota, se debe marcar un punto y enviar un caracter al arduino para que encienda y apague las luces con un delay.

- Cuando el jugador pierda la partida, se debe mostrar el puntaje obtenido por el usuario y las dos luces deben permanecer encendidas.


Mucha suerte !

